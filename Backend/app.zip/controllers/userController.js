let user = require("../models/userModel");

// @param {*} req
// @param {*} res
// @param {*} next

let getUserList = async (req, res, next) => {

    try {

        console.time("userController : getUserList");
        const data = await user.findAll(
            {
                where: { isDeleted: false },
                raw: true,
            });
        let noOfRecords = data.length;
        console.timeEnd("userController : getUserList");
        res.status(200).json({
            noOfRecords: noOfRecords,
            data: data,
        });
    } catch (err) {
        next(err);
    }
};

let getUser = async (req, res, next) => {
    try {
        console.time("userController : getUser");
        const userId = req.params.id;
        console.log("userController : getUser :: userId is :", userId);
        const data = await user.findOne(
            {
                where: { id: userId, isDeleted: false },
                raw: true,
                attributes: [
                    'id', 'name', 'type', 'address', 'email' , ' password',i
                ]
            });
        console.timeEnd("userController : getUser");
        res.status(200).json({
            data: data,
        });
    } catch (err) {
        next(err);
    }
};

let createUser = async (req, res, next) => {
    try {
        const { name, type, address } = req.body;

        const isUserExists = await user.findOne({ where: { name: name } });
        console.log("userController : createUser :: isUserExists :", isUserExists);

        if (isUserExists) {
            res.status(409).json({
                error: true,
                message: "User with name already exists..",
                data: null
            });
        } else {
            const data = await user.create({
                name,
                type,
                address,
            })
            console.log(data);
            res.status(200).json({
                data: data,
            });
        }
    } catch (err) {
        next(err);
    }
};

let updateUser = async (req, res, next) => {
    try {
        const { id, name, type, address } = req.body;

        console.log("userController : updateUser :: id : ", id);
        const userData = await user.findOne({ where: { id: id } });


        if (!userData) {
            res.status(404).json({
                error: true,
                message: "User does not exists..",
                data: null
            });
        } else {
            const updateData = await user.update(
                {
                    name,
                    type,
                    address,
                },
                {
                    where: { id: id },
                });

            console.log("userController : updateUser", updateData);
            res.status(200).json({
                name: name,
                type: type,
                address: address,
            })
        }
    } catch (err) {
        next(err);
    }

}


let deleteUser = async (req, res, next) => {
    try {
        console.time("userController : deleteUser");
        let { id } = req.params;
        console.log("userController : deleteUser :: Deleting user with id " + id);
        await user.update(
            {
                isDeleted: true,
            },
            { where: { id: id } }
        );
        console.timeEnd("userController : deleteUser");
        res.status(200).json();
    } catch (err) {
        next(err);
    }
};


module.exports = {
    getUserList,
    getUser,
    createUser,
    updateUser,
    deleteUser,
};